import pytz
import jdatetime
from datetime import datetime

def iran_now():
    tz = pytz.timezone('Asia/Tehran')
    now = datetime.now(tz)
    shamsi = jdatetime.datetime.fromgregorian(datetime=now)
    return {'gregorian': now, 'shamsi': shamsi}
