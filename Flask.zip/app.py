# صفحه سبد خرید
from flask import Flask, render_template, redirect, url_for, request, flash, session
from utils_time import iran_now
from flask_sqlalchemy import SQLAlchemy
import os
from PIL import Image

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///shop.db'
db = SQLAlchemy(app)

@app.route('/admin/edit/<int:product_id>', methods=['GET', 'POST'])
def edit_product(product_id):
    if not session.get('admin'):
        return redirect(url_for('admin_login'))
    product = Product.query.get_or_404(product_id)
    uploads_dir = app.config['UPLOAD_FOLDER']
    gallery_images = []
    if os.path.exists(uploads_dir):
        gallery_images = [f for f in os.listdir(uploads_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png', '.gif', '.webp'))]

    if request.method == 'POST':
        product.name = request.form['name']
        product.price = float(request.form['price'])
        product.coworker_price = request.form.get('coworker_price') or None
        if product.coworker_price:
            product.coworker_price = float(product.coworker_price)
        product.description = request.form['description']
        product.stock = int(request.form.get('stock', 1))
        selected_gallery = request.form.get('gallery_image')
        if selected_gallery:
            product.image = selected_gallery
        else:
            image_file = request.files.get('image')
            if image_file and image_file.filename:
                ext = os.path.splitext(image_file.filename)[1].lower()
                if ext in ['.jpg', '.jpeg', '.png', '.gif', '.webp']:
                    image_filename = f"{product.name}_{int(product.price)}_{os.urandom(4).hex()}{ext}"
                    image_path = os.path.join(app.config['UPLOAD_FOLDER'], image_filename)
                    img = Image.open(image_file)
                    img = img.convert('RGB') if ext in ['.jpg', '.jpeg'] else img.convert('RGBA')
                    img = img.resize((250, 250), Image.LANCZOS)
                    img.save(image_path)
                    product.image = image_filename
        db.session.commit()
        flash('محصول با موفقیت ویرایش شد')
        return redirect(url_for('admin_panel'))
    return render_template('edit_product.html', product=product, gallery_images=gallery_images)

@app.route('/add_to_cart/<int:product_id>', methods=['POST'])
def add_to_cart(product_id):
    quantity = int(request.form.get('quantity', 1))
    cart = session.get('cart', {})
    if str(product_id) in cart:
        cart[str(product_id)] += quantity
    else:
        cart[str(product_id)] = quantity
    session['cart'] = cart
    flash('محصول به سبد خرید اضافه شد')
    return redirect(url_for('index'))

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    code = db.Column(db.String(50), unique=True, nullable=True)  # شناسه محصول
    price = db.Column(db.Float, nullable=False)
    coworker_price = db.Column(db.Float, nullable=True)
    description = db.Column(db.Text, nullable=True)
    image = db.Column(db.String(200), nullable=True)
    stock = db.Column(db.Integer, nullable=False, default=1)


# مدل‌های سفارش بعد از مقداردهی db
class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customer_name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    address = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, server_default=db.func.now())
    items = db.relationship('OrderItem', backref='order', lazy=True)

class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    product_name = db.Column(db.String(100), nullable=False)
    product_code = db.Column(db.String(50), nullable=True)  # شناسه محصول
    price = db.Column(db.Float, nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
from flask import send_from_directory
app.config['UPLOAD_FOLDER'] = os.path.join('static', 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024  # 2MB

class Admin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    is_coworker = db.Column(db.Boolean, default=False)
    address = db.Column(db.Text, nullable=True)
    phone = db.Column(db.String(20), nullable=True)

# حذف سفارش (فاکتور)
@app.route('/admin/delete_order/<int:order_id>', methods=['POST'])
def delete_order(order_id):
    if not session.get('admin', False):
        return redirect(url_for('index'))
    order = Order.query.get_or_404(order_id)
    # بازگرداندن موجودی محصولات و حذف آیتم‌های سفارش
    for item in order.items:
        product = Product.query.get(item.product_id)
        if product:
            product.stock += item.quantity
            db.session.add(product)
        db.session.delete(item)
    db.session.delete(order)
    db.session.commit()
    flash('سفارش حذف شد و موجودی محصولات بازگردانده شد')
    return redirect(url_for('admin_orders'))

# ثبت سفارش و ذخیره فاکتور
@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    cart = session.get('cart', {})
    cart_items = []
    total = 0
    for product_id, quantity in cart.items():
        product = Product.query.get(int(product_id))
        if product:
            item_total = (product.coworker_price or 0) * quantity
            cart_items.append({
                'id': product.id,
                'name': product.name,
                'image': product.image,
                'price': product.coworker_price,
                'quantity': quantity,
                'item_total': item_total
            })
            total += item_total
    if request.method == 'POST':
        # اگر همکار لاگین است، اطلاعات را از پروفایل بگیرد
        admin_id = session.get('admin_id')
        admin = None
        if admin_id:
            admin = Admin.query.get(admin_id)
        if admin and admin.is_coworker:
            name = admin.username
            phone = admin.phone or ''
            address = admin.address or ''
        else:
            name = ''
            phone = ''
            address = ''

        # بررسی موجودی همه محصولات
        for item in cart_items:
            product = Product.query.get(item['id'])
            if not product or product.stock < item['quantity']:
                flash(f"موجودی محصول '{item['name']}' کافی نیست.", 'error')
                return render_template('checkout.html', cart_items=cart_items, total=total)

        try:
            order = Order(customer_name=name, phone=phone, address=address)
            db.session.add(order)
            db.session.flush()  # تا order.id داشته باشیم
            for item in cart_items:
                product = Product.query.get(item['id'])
                if not product or product.stock < item['quantity']:
                    db.session.rollback()
                    flash(f"موجودی محصول '{item['name']}' کافی نیست.", 'error')
                    return render_template('checkout.html', cart_items=cart_items, total=total)
                order_item = OrderItem(
                    order_id=order.id,
                    product_id=item['id'],
                    product_name=item['name'],
                    product_code=product.code,
                    price=item['price'],
                    quantity=item['quantity']
                )
                db.session.add(order_item)
                product.stock -= item['quantity']
                db.session.add(product)
            db.session.commit()
            session['cart'] = {}
            return render_template('order_success.html', order=order, cart_items=cart_items, total=total)
        except Exception as e:
            db.session.rollback()
            flash('خطا در ثبت سفارش. لطفاً دوباره تلاش کنید.', 'error')
            return render_template('checkout.html', cart_items=cart_items, total=total)
    return render_template('checkout.html', cart_items=cart_items, total=total)


@app.context_processor
def inject_iran_time():
    def iran_time():
        t = iran_now()
        return t
    return {'iran_time': iran_time}

@app.route('/')
def index():
    products = Product.query.all()
    is_coworker = session.get('is_coworker', False)
    is_admin = session.get('admin', False)
    return render_template('index.html', products=products, is_coworker=is_coworker, is_admin=is_admin)

@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        admin = Admin.query.filter_by(username=username, password=password).first()
        if admin:
            session['is_coworker'] = admin.is_coworker
            session['admin'] = not admin.is_coworker
            session['admin_id'] = admin.id
            return redirect(url_for('admin_panel'))
        else:
            flash('نام کاربری یا رمز عبور اشتباه است', 'login')
    return render_template('admin_login.html')

@app.route('/admin/panel')
def admin_panel():
    if not session.get('admin', False):
        return redirect(url_for('index'))
    products = Product.query.all()
    return render_template('admin_panel.html', products=products)

@app.route('/admin/add', methods=['GET', 'POST'])
def add_product():
    if not session.get('admin', False):
        return redirect(url_for('index'))
    uploads_dir = app.config['UPLOAD_FOLDER']
    gallery_images = []
    if os.path.exists(uploads_dir):
        gallery_images = [f for f in os.listdir(uploads_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png', '.gif', '.webp'))]

    uploads_dir = app.config['UPLOAD_FOLDER']
    gallery_images = []
    if os.path.exists(uploads_dir):
        gallery_images = [f for f in os.listdir(uploads_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png', '.gif', '.webp'))]

    if request.method == 'POST':
        name = request.form['name']
        code = request.form['code']
        coworker_price = request.form.get('coworker_price') or None
        if coworker_price:
            coworker_price = float(coworker_price)
        description = request.form['description']
        stock = int(request.form.get('stock', 1))
        selected_gallery = request.form.get('gallery_image')
        image_filename = None
        if selected_gallery:
            image_filename = selected_gallery
        else:
            image_file = request.files.get('image')
            if image_file and image_file.filename:
                ext = os.path.splitext(image_file.filename)[1].lower()
                if ext in ['.jpg', '.jpeg', '.png', '.gif', '.webp']:
                    image_filename = f"{name}_{os.urandom(4).hex()}{ext}"
                    image_path = os.path.join(app.config['UPLOAD_FOLDER'], image_filename)
                    from PIL import Image
                    img = Image.open(image_file)
                    img = img.convert('RGB') if ext in ['.jpg', '.jpeg'] else img.convert('RGBA')
                    img = img.resize((250, 250), Image.LANCZOS)
                    img.save(image_path)
        product = Product(name=name, code=code, price=0, coworker_price=coworker_price, description=description, image=image_filename, stock=stock)
        db.session.add(product)
        db.session.commit()
        flash('محصول با موفقیت افزوده شد')
        return redirect(url_for('admin_panel'))
    return render_template('add_product.html', gallery_images=gallery_images)

# حذف محصول
@app.route('/admin/delete/<int:product_id>', methods=['POST'])
def delete_product(product_id):
    if not session.get('admin', False):
        return redirect(url_for('index'))
    product = Product.query.get_or_404(product_id)
    db.session.delete(product)
    db.session.commit()
    return redirect(url_for('admin_panel'))

@app.route('/logout')
def logout():
    session.pop('admin', None)
    session.pop('is_coworker', None)
    return redirect(url_for('index'))

# ساخت کاربر همکار
@app.route('/admin/add_coworker', methods=['GET', 'POST'])
def add_coworker():
    if not session.get('admin', False):
        return redirect(url_for('index'))
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        address = request.form.get('address')
        phone = request.form.get('phone')
        if Admin.query.filter_by(username=username).first():
            flash('این نام کاربری قبلاً ثبت شده است')
        else:
            coworker = Admin(username=username, password=password, is_coworker=True, address=address, phone=phone)
            db.session.add(coworker)
            db.session.commit()
            flash('کاربر همکار با موفقیت افزوده شد')
    return render_template('add_coworker.html')

@app.template_filter('toman')
def toman_format(value):
    try:
        value = float(value)
        return '{:,.0f} تومان'.format(value)
    except:
        return value


# ------------------- مدیریت همکارها -------------------
@app.route('/admin/coworkers')
def admin_coworkers():
    if not session.get('admin', False):
        return redirect(url_for('index'))
    coworkers = Admin.query.filter_by(is_coworker=True).all()
    return render_template('admin_coworkers.html', coworkers=coworkers)

@app.route('/admin/delete_coworker/<int:coworker_id>', methods=['POST'])
def delete_coworker(coworker_id):
    if not session.get('admin', False):
        return redirect(url_for('index'))
    coworker = Admin.query.get_or_404(coworker_id)
    if coworker.is_coworker:
        db.session.delete(coworker)
        db.session.commit()
        flash('همکار حذف شد')
    return redirect(url_for('admin_coworkers'))

@app.route('/admin/edit_coworker/<int:coworker_id>', methods=['GET', 'POST'])
def edit_coworker(coworker_id):
    if not session.get('admin', False):
        return redirect(url_for('index'))
    coworker = Admin.query.get_or_404(coworker_id)
    if not coworker.is_coworker:
        return redirect(url_for('admin_coworkers'))
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        coworker.username = username
        if password:
            coworker.password = password
        db.session.commit()
        flash('اطلاعات همکار ویرایش شد')
        return redirect(url_for('admin_coworkers'))
    return render_template('edit_coworker.html', coworker=coworker)

@app.route('/admin/orders')
def admin_orders():
    if not session.get('admin', False):
        return redirect(url_for('index'))
    orders = Order.query.order_by(Order.created_at.desc()).all()
    return render_template('admin_orders.html', orders=orders)



# صفحه سبد خرید
@app.route('/cart')
def cart():
    cart = session.get('cart', {})
    cart_items = []
    total = 0
    for product_id, quantity in cart.items():
        product = Product.query.get(int(product_id))
        if product:
            item_total = (product.coworker_price or 0) * quantity
            cart_items.append({
                'id': product.id,
                'name': product.name,
                'image': product.image,
                'price': product.coworker_price,
                'quantity': quantity,
                'item_total': item_total
            })
            total += item_total
    return render_template('cart.html', cart_items=cart_items, total=total)

# حذف محصول از سبد خرید
@app.route('/remove_from_cart/<int:product_id>', methods=['POST'])
def remove_from_cart(product_id):
    cart = session.get('cart', {})
    product_id_str = str(product_id)
    if product_id_str in cart:
        del cart[product_id_str]
        session['cart'] = cart
        flash('محصول از سبد خرید حذف شد')
    return redirect(url_for('cart'))

@app.route('/set_cart', methods=['POST'])
def set_cart():
    cart = {}
    for key, value in request.form.items():
        if key.startswith('quantity_'):
            try:
                product_id = key.split('_', 1)[1]
                quantity = int(value)
                if quantity > 0:
                    cart[product_id] = quantity
            except Exception:
                continue
    session['cart'] = cart
    return redirect(url_for('cart'))

@app.route('/remove_quantity_from_cart/<int:product_id>', methods=['POST'])
def remove_quantity_from_cart(product_id):
    cart = session.get('cart', {})
    product_id_str = str(product_id)
    remove_qty = int(request.form.get('remove_quantity', 1))
    if product_id_str in cart:
        if cart[product_id_str] > remove_qty:
            cart[product_id_str] -= remove_qty
            flash(f'{remove_qty} عدد از محصول حذف شد')
        else:
            del cart[product_id_str]
            flash('محصول از سبد خرید حذف شد')
        session['cart'] = cart
    return redirect(url_for('cart'))

@app.route('/clear_cart', methods=['POST'])
def clear_cart():
    session['cart'] = {}
    flash('سبد خرید شما خالی شد')
    return redirect(url_for('cart'))

if __name__ == '__main__':
    if not os.path.exists('shop.db'):
        with app.app_context():
            db.create_all()
            # ایجاد ادمین پیش‌فرض فقط اگر وجود ندارد
            if not Admin.query.filter_by(username='admin').first():
                admin = Admin(username='admin', password='admin')
                db.session.add(admin)
                db.session.commit()
    app.run(host='0.0.0.0', port=5000, debug=True)
